const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const port = 3000;

// Configuration d'EJS et du dossier de vues
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware pour parser les formulaires
app.use(express.urlencoded({ extended: true }));

// Connexion à MySQL (via XAMPP)
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',       // modifiez si besoin
  password: '',       // par défaut, XAMPP n'a pas de mot de passe
  database: 'gestion_des_stages_ines'
});

db.connect(err => {
  if (err) {
    console.error('Erreur de connexion à MySQL:', err);
  } else {
    console.log('Connecté à la base de données MySQL');
  }
});

/* Routes */

// Page d'accueil : Affichage de la liste des stagiaires
app.get('/', (req, res) => {
  const sql = "SELECT * FROM stages ORDER BY date_debut DESC";
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la récupération des stagiaires");
    } else {
      res.render('stages', { stages: results });
    }
  });
});

// Formulaire d'ajout d'un stagiaire
app.get('/ajouter-stagiaire', (req, res) => {
  res.render('ajouter-stage', {
    stage: {},
    action: '/ajouter-stagiaire',
    buttonText: 'Ajouter'
  });
});

// Traitement de l'ajout (INSERT dans la table "stages")
app.post('/ajouter-stagiaire', (req, res) => {
  const { id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin } = req.body;
  const sql = "INSERT INTO stages (id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin) VALUES (?, ?, ?, ?, ?, ?, ?)";
  db.query(sql, [id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin], (err, result) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de l'ajout du stagiaire");
    } else {
      res.redirect('/');
    }
  });
});

// Formulaire de modification d'un stagiaire
app.get('/modifier-stagiaire/:id', (req, res) => {
  const id = req.params.id;
  const sql = "SELECT * FROM stages WHERE id_stage = ?";
  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la récupération du stagiaire");
    } else if (results.length > 0) {
      res.render('modifier-stage', {
        stage: results[0],
        action: `/modifier-stagiaire/${id}`,
        buttonText: 'Modifier'
      });
    } else {
      res.redirect('/');
    }
  });
});

// Traitement de la modification (UPDATE dans la table "stages")
app.post('/modifier-stagiaire/:id', (req, res) => {
  const id = req.params.id;
  const { id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin } = req.body;
  const sql = "UPDATE stages SET id_etudiant = ?, nom = ?, prenom = ?, titre = ?, entreprise = ?, date_debut = ?, date_fin = ? WHERE id_stage = ?";
  db.query(sql, [id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin, id], (err, result) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la modification du stagiaire");
    } else {
      res.redirect('/');
    }
  });
});

// Suppression d'un stagiaire (DELETE dans la table "stages")
app.get('/supprimer-stagiaire/:id', (req, res) => {
  const id = req.params.id;
  const sql = "DELETE FROM stages WHERE id_stage = ?";
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la suppression du stagiaire");
    } else {
      res.redirect('/');
    }
  });
});

// Route de recherche côté serveur
app.get('/search', (req, res) => {
  const query = req.query.q;
  if (!query) return res.redirect('/');
  const likeQuery = `%${query}%`;
  // Rechercher dans les colonnes titre, entreprise, nom ou prenom
  const sql = "SELECT * FROM stages WHERE titre LIKE ? OR entreprise LIKE ? OR nom LIKE ? OR prenom LIKE ?";
  db.query(sql, [likeQuery, likeQuery, likeQuery, likeQuery], (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la recherche des stagiaires");
    } else {
      res.render('stages', { stages: results });
    }
  });
});


app.get('/', (req, res) => {
  const sql = "SELECT * FROM stages ORDER BY date_debut DESC";
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la récupération des stagiaires");
    } else {
      res.render('stages', { stages: results });
    }
  });
});

app.get('/', (req, res) => {
  const sql = "SELECT * FROM stages ORDER BY date_debut DESC";
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la récupération des stagiaires");
    } else {
      res.render('stages', { stagiaires: results });
    }
  });
});

app.get('/', (req, res) => {
  const sql = `
    SELECT id_stage, id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin 
    FROM stages 
    ORDER BY date_debut DESC
  `;
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la récupération des stagiaires");
    } else {
      res.render('stages', { stages: results });
    }
  });
});

app.get('/search', (req, res) => {
  const q = req.query.q;
  if (!q) {
    return res.redirect('/');
  }
  const sql = `
    SELECT * FROM stages 
    WHERE titre LIKE ? 
       OR entreprise LIKE ? 
       OR nom LIKE ? 
       OR prenom LIKE ?
    ORDER BY date_debut DESC
  `;
  const likeQuery = `%${q}%`;
  db.query(sql, [likeQuery, likeQuery, likeQuery, likeQuery], (err, results) => {
    if (err) {
      console.error(err);
      return res.send("Erreur lors de la recherche des stages");
    }
    // On passe le résultat à la vue, ici la variable "stages" est utilisée
    res.render('stages', { stages: results });
  });
});




app.get('/', (req, res) => {
  const sql = "SELECT * FROM stages ORDER BY date_debut DESC";
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la récupération des stagiaires");
    } else {
      res.render('stages', { stages: results });
    }
  });
});

app.listen(port, () => {
  console.log(`Serveur lancé sur http://localhost:${port}`);
});
