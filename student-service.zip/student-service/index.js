const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const path = require('path');

const app = express();

// Création du pool de connexions à MySQL (XAMPP)
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '', // Mettez votre mot de passe si nécessaire
  database: 'gestion_des_stages_ines',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Configuration du moteur de vues EJS et des dossiers
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// Route : Afficher la liste des étudiants
app.get('/etudiants', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM etudiants');
    res.render('index', { etudiants: rows });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Route : Afficher le formulaire d'ajout d'un étudiant
app.get('/etudiants/add', (req, res) => {
  res.render('add');
});

// Route : Traiter l'ajout d'un étudiant
app.post('/etudiants/add', async (req, res) => {
  const { nom, prenom, email, adresse, date_naissance } = req.body;
  try {
    await pool.query(
      'INSERT INTO etudiants (nom, prenom, email, adresse, date_naissance) VALUES (?, ?, ?, ?, ?)',
      [nom, prenom, email, adresse, date_naissance]
    );
    res.redirect('/etudiants');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Route : Afficher le formulaire de modification d'un étudiant
app.get('/etudiants/edit/:id', async (req, res) => {
  const { id } = req.params;
  try {
    // Utiliser id_etudiant qui correspond à la colonne dans la table
    const [rows] = await pool.query('SELECT * FROM etudiants WHERE id_etudiant = ?', [id]);
    if (rows.length === 0) {
      res.status(404).send("Étudiant non trouvé");
    } else {
      res.render('edit', { etudiant: rows[0] });
    }
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Route : Traiter la modification d'un étudiant
app.post('/etudiants/edit/:id', async (req, res) => {
  const { id } = req.params;
  const { nom, prenom, email, adresse, date_naissance } = req.body;
  try {
    await pool.query(
      'UPDATE etudiants SET nom = ?, prenom = ?, email = ?, adresse = ?, date_naissance = ? WHERE id_etudiant = ?',
      [nom, prenom, email, adresse, date_naissance, id]
    );
    res.redirect('/etudiants');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Route : Supprimer un étudiant avec POST
app.post('/etudiants/delete/:id', async (req, res) => {
  const { id } = req.params;
  try {
    // Supprimer les évaluations liées à l'étudiant
    await pool.query('DELETE FROM evaluations WHERE id_etudiant = ?', [id]);

    // Supprimer l'étudiant
    await pool.query('DELETE FROM etudiants WHERE id_etudiant = ?', [id]);

    res.redirect('/etudiants');
  } catch (error) {
    res.status(500).send(error.message);
  }
});



// Redirection de la racine vers la liste des étudiants
app.get('/', (req, res) => {
  res.redirect('/etudiants');
});

// Middleware de gestion des erreurs
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: err.message });
});

// Lancement du serveur
const PORT = 3004;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur http://localhost:${PORT}`);
});
