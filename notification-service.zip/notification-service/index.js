// server.js
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const nodemailer = require('nodemailer');
const path = require('path');

const app = express();

// Configuration du moteur de template EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware pour servir les fichiers statiques et parser les formulaires
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));

// Configuration de la connexion MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // adaptez en fonction de votre configuration XAMPP
    database: 'gestion_des_stages_ines'
});

db.connect((err) => {
    if (err) {
        console.error('Erreur de connexion MySQL: ', err);
    } else {
        console.log('Connecté à la base de données MySQL');
    }
});

// Configuration de Nodemailer (exemple avec Gmail)
// Pensez à activer "l'accès aux applications moins sécurisées" ou utiliser un mot de passe d'application
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'votre.email@gmail.com',
        pass: 'votre_mot_de_passe'
    }
});

// --- Routes ---

// Page d'accueil avec formulaire pour ajouter une notification
app.get('/', (req, res) => {
    res.render('index');
});

// Affichage de la liste des notifications
app.get('/notifications', (req, res) => {
    const sql = 'SELECT * FROM notifications ORDER BY created_at DESC';
    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).send('Erreur lors de la récupération des notifications');
        }
        res.render('notifications', { notifications: results });
    });
});

// Ajout d'une notification et envoi d'email aux étudiants
app.post('/notifications/add', (req, res) => {
    const { title, message } = req.body;
    const sqlInsert = 'INSERT INTO notifications (title, message) VALUES (?, ?)';
    
    db.query(sqlInsert, [title, message], (err, result) => {
        if (err) {
            return res.status(500).send('Erreur lors de l\'ajout de la notification');
        }
        
        // Récupérer les emails des étudiants
        const sqlStudents = 'SELECT email FROM students';
        db.query(sqlStudents, (err, students) => {
            if (err) {
                return res.status(500).send('Erreur lors de la récupération des étudiants');
            }
            
            if (students.length === 0) {
                console.log("Aucun étudiant trouvé dans la base de données.");
                return res.redirect('/notifications');
            }

            // Préparation de l'email
            const mailOptions = {
                from: 'votre.email@gmail.com',  // adresse de l'expéditeur
                to: students.map(student => student.email).join(','),
                subject: `Nouvelle notification: ${title}`,
                text: message
            };

            // Envoi de l'email
            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.error('Erreur lors de l\'envoi de l\'email: ', error);
                    return res.status(500).send('Erreur lors de l\'envoi de l\'email');
                } else {
                    console.log('Email envoyé: ' + info.response);
                    res.redirect('/notifications');
                }
            });
        });
    });
});
app.get('/', (req, res) => {
  const sql = 'SELECT * FROM notifications ORDER BY created_at DESC';
  db.query(sql, (err, results) => {
      if (err) {
          return res.status(500).send('Erreur lors de la récupération des notifications');
      }
      res.render('index', { notifications: results });
  });
});
// Route pour afficher le formulaire d'ajout de notification
app.get('/add', (req, res) => {
  res.render('add'); // Assurez-vous d'avoir une vue "add.ejs"
});

// Démarrage du serveur
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Serveur démarré sur le port ${PORT}`);
});
