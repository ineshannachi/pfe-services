const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const port = 3000;

// Configuration d'EJS et du dossier de vues
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware pour parser les formulaires
app.use(express.urlencoded({ extended: true }));

// Connexion à MySQL (via XAMPP)
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',       // modifiez si besoin
  password: '',       // par défaut, XAMPP n'a pas de mot de passe
  database: 'gestion_des_stages_ines'
});

db.connect(err => {
  if (err) {
    console.error('Erreur de connexion à MySQL:', err);
  } else {
    console.log('Connecté à la base de données MySQL');
  }
});

/* Routes */

// Page d'accueil
app.get('/', (req, res) => {
  res.render('index');
});

// Liste des évaluations avec jointure sur la table etudiants
app.get('/evaluations', (req, res) => {
  const sql = `
    SELECT e.id_evaluation, e.id_etudiant, CONCAT(s.nom, ' ', s.prenom) AS nom_prenom, 
           e.note, e.date_evaluation 
    FROM evaluations e 
    JOIN etudiants s ON e.id_etudiant = s.id_etudiant 
    ORDER BY e.date_evaluation DESC
  `;
  
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la récupération des évaluations");
    } else {
      res.render('evaluations', { evaluations: results });
    }
  });
});


// Formulaire d'ajout d'une évaluation
app.get('/ajouter-evaluation', (req, res) => {
  res.render('ajouter-evaluation');
});

// Traitement de l'ajout d'une évaluation
app.post('/ajouter-evaluation', (req, res) => {
  // Récupérer id_etudiant, nom, prenom, note et date_evaluation depuis le formulaire
  const { id_etudiant, nom, prenom, note, date_evaluation } = req.body;
  const sql = `INSERT INTO evaluations (id_etudiant, nom, prenom, note, date_evaluation)
               VALUES (?, ?, ?, ?, ?)`;
  db.query(sql, [id_etudiant, nom, prenom, note, date_evaluation], (err, result) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de l'ajout de l'évaluation");
    } else {
      res.redirect('/evaluations');
    }
  });
});


// Route d'édition : "/edit/:id"
// Assurez-vous d'appeler cette URL avec un identifiant (par exemple, /edit/1)
app.get('/edit/:id', (req, res) => {
  const id = req.params.id;
  const sql = `SELECT * FROM evaluations WHERE id_evaluation = ?`;
  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la récupération de l'évaluation");
    } else if (results.length > 0) {
      res.render('edit-evaluation', { evaluation: results[0] });
    } else {
      res.redirect('/evaluations');
    }
  });
});

// Traitement de la modification d'une évaluation via la route "/edit/:id"
app.post('/edit/:id', (req, res) => {
  const id = req.params.id;
  const { id_etudiant, nom, prenom, note, date_evaluation } = req.body;
  const sql = `UPDATE evaluations 
               SET id_etudiant = ?, nom = ?, prenom = ?, note = ?, date_evaluation = ? 
               WHERE id_evaluation = ?`;
  db.query(sql, [id_etudiant, nom, prenom, note, date_evaluation, id], (err, result) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la modification de l'évaluation");
    } else {
      res.redirect('/evaluations');
    }
  });
});


// Suppression d'une évaluation
app.get('/delete/:id', (req, res) => {
  const id = req.params.id;
  const sql = `DELETE FROM evaluations WHERE id_evaluation = ?`;
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la suppression de l'évaluation");
    } else {
      res.redirect('/evaluations');
    }
  });
});

// Détail d'une évaluation (par exemple, la dernière évaluation)
app.get('/mon-evaluation', (req, res) => {
  const sql = `SELECT * FROM evaluations ORDER BY date_evaluation DESC LIMIT 1`;
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la récupération de l'évaluation");
    } else if (results.length > 0) {
      res.render('mon-evaluation', { evaluation: results[0] });
    } else {
      res.send("Aucune évaluation trouvée");
    }
  });
});

app.post('/edit-evaluation/:id', (req, res) => {
  const id = req.params.id;
  // Récupération des valeurs envoyées par le formulaire
  const { id_etudiant, nom, prenom, note, date_evaluation } = req.body;
  const sql = `UPDATE evaluations 
               SET id_etudiant = ?, nom = ?, prenom = ?, note = ?, date_evaluation = ? 
               WHERE id_evaluation = ?`;
  db.query(sql, [id_etudiant, nom, prenom, note, date_evaluation, id], (err, result) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de la modification de l'évaluation");
    } else {
      res.redirect('/evaluations');
    }
  });
});

app.post('/ajouter-evaluation', (req, res) => {
  const { id_etudiant, nom, prenom, note, date_evaluation } = req.body;
  const sql = `INSERT INTO evaluations (id_etudiant, nom, prenom, note, date_evaluation) VALUES (?, ?, ?, ?, ?)`;
  db.query(sql, [id_etudiant, nom, prenom, note, date_evaluation], (err, result) => {
    if (err) {
      console.error(err);
      res.send("Erreur lors de l'ajout de l'évaluation");
    } else {
      res.redirect('/evaluations');
    }
  });
});


app.listen(port, () => {
  console.log(`Serveur lancé sur http://localhost:${port}`);
});
