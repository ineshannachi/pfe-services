const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const mysql = require('mysql');
const session = require('express-session'); // Importer express-session

const app = express();

// Middleware pour gérer les données des formulaires et JSON
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Utilisation de express-session pour gérer la session
app.use(session({
  secret: 'votre_clé_secrète',  // Changez cette clé pour une clé secrète plus sécurisée
  resave: false,
  saveUninitialized: true
}));

// Configuration du moteur de templates EJS et dossier des vues
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Connexion à MySQL (via XAMPP)
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',       // modifiez si besoin
  password: '',       // par défaut, XAMPP n'a pas de mot de passe
  database: 'gestion_des_stages_ines'
});

db.connect(err => {
  if (err) {
    console.error('Erreur de connexion à MySQL:', err);
  } else {
    console.log('Connecté à la base de données MySQL');
  }
});

// Page d'accueil
app.get('/', (req, res) => {
  res.render('index');
});

// 🔒 Formulaire d'inscription
app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', async (req, res) => {
  const { nom_utilisateur, email, password, role } = req.body;

  if (!nom_utilisateur || !email || !password || !role) {
    return res.status(400).json({ message: 'Tous les champs sont requis' });
  }

  // Vérifier si le nom d'utilisateur existe déjà
  const checkUserSql = 'SELECT * FROM users WHERE nom_utilisateur = ?';
  db.query(checkUserSql, [nom_utilisateur], async (err, results) => {
    if (err) {
      console.error('Erreur lors de la vérification du nom d\'utilisateur:', err);
      return res.status(500).json({ message: 'Erreur serveur' });
    }

    if (results.length > 0) {
      return res.status(400).json({ message: 'Le nom d\'utilisateur est déjà pris' });
    }

    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const sql = 'INSERT INTO users (nom_utilisateur, email, password, role) VALUES (?, ?, ?, ?)';
      db.query(sql, [nom_utilisateur, email, hashedPassword, role], (err) => {
        if (err) {
          console.error('Erreur d’inscription:', err);
          return res.status(500).json({ message: 'Erreur d’inscription' });
        }
        res.redirect('/login'); // Redirection vers la page de connexion après une inscription réussie
      });
    } catch (err) {
      console.error('Erreur de chiffrement:', err);
      res.status(500).json({ message: 'Erreur de chiffrement' });
    }
  });
});

// 🔒 Formulaire de connexion
app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', async (req, res) => {
  console.log("POST /login received");

  // Récupérer les données du formulaire
  const { email, password } = req.body;

  // Vérifier que les champs email et mot de passe existent
  if (!email || !password) {
    return res.status(400).json({ message: 'Email et mot de passe sont requis' });
  }

  // Requête SQL pour trouver l'utilisateur avec cet email
  const sql = 'SELECT * FROM users WHERE email = ?';
  db.query(sql, [email], async (err, results) => {
    if (err) {
      console.error("Erreur lors de la connexion à la base de données :", err);
      return res.status(500).json({ message: 'Erreur de connexion' });
    }

    
   
    // Redirection vers le tableau de bord après une connexion réussie
    res.redirect('/dashboard');
  });
});

// Route /dashboard (tableau de bord)
app.get('/dashboard', (req, res) => {
  // Vérifier si l'utilisateur est connecté
  if (!req.session.userId) {
    return res.redirect('/login'); // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
  }

  // Si l'utilisateur est connecté, afficher la page du tableau de bord
  res.render('dashboard', { user: req.session });
});

// Route pour se déconnecter
app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: 'Erreur lors de la déconnexion' });
    }
    res.redirect('/login'); // Rediriger vers la page de connexion après la déconnexion
  });
});


// Démarrer le serveur
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Service de gestion des stages en cours sur http://localhost:${PORT}`);
});
