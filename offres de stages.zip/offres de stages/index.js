const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const path = require('path');

const app = express();

// Configuration de la connexion MySQL (XAMPP)
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '', // Modifiez si nécessaire
  database: 'gestion_des_stages_ines',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Configuration du moteur de vues EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// Route d'accueil : redirige vers la liste des offres
app.get('/', (req, res) => {
  res.redirect('/offres');
});

// Afficher la liste des offres de stage
app.get('/offres', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM offres_de_stage ORDER BY date_creation DESC');
    res.render('offres', { offres: rows });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Afficher le formulaire de création d'une offre de stage (sans champ id_etudiant)
app.get('/offres/nouveau', (req, res) => {
  res.render('offreStageForm');
});

// Traiter la création d'une offre de stage
app.post('/offres', async (req, res) => {
  const { titre, entreprise, description, date_debut, date_fin, lieu } = req.body;
  try {
    // Insère NULL pour id_etudiant puisque le champ est supprimé du formulaire
    await pool.query(
      'INSERT INTO offres_de_stage (id_etudiant, titre, entreprise, description, date_debut, date_fin, lieu, date_creation) VALUES (NULL, ?, ?, ?, ?, ?, ?, NOW())',
      [titre, entreprise, description, date_debut, date_fin, lieu]
    );
    res.redirect('/offres');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Afficher le formulaire de modification d'une offre (sans champ id_etudiant)
app.get('/offres/:id/edit', async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await pool.query('SELECT * FROM offres_de_stage WHERE id_offre = ?', [id]);
    if (rows.length === 0) return res.status(404).send('Offre non trouvée');
    res.render('editOffre', { offre: rows[0] });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Traiter la modification d'une offre
app.post('/offres/:id/edit', async (req, res) => {
  const { id } = req.params;
  const { titre, entreprise, description, date_debut, date_fin, lieu } = req.body;
  try {
    await pool.query(
      'UPDATE offres_de_stage SET titre = ?, entreprise = ?, description = ?, date_debut = ?, date_fin = ?, lieu = ? WHERE id_offre = ?',
      [titre, entreprise, description, date_debut, date_fin, lieu, id]
    );
    res.redirect('/offres');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Traiter la suppression d'une offre
app.post('/offres/:id/delete', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM offres_de_stage WHERE id_offre = ?', [id]);
    res.redirect('/offres');
  } catch (error) {
    res.status(500).send(error.message);
  }
});
// Route : Traiter la création d'une offre de stage
app.post('/offres', async (req, res) => {
  const { titre, entreprise, description, date_debut, date_fin, lieu, email, contact } = req.body;
  try {
    await pool.query(
      `INSERT INTO offres_de_stage 
      (id_etudiant, titre, entreprise, description, date_debut, date_fin, lieu, email, contact, date_creation) 
      VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [titre, entreprise, description, date_debut, date_fin, lieu, email, contact]
    );
    res.redirect('/offres');
  } catch (error) {
    res.status(500).send(error.message);
  }
});


const PORT = 3025;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur http://localhost:${PORT}`);
});
